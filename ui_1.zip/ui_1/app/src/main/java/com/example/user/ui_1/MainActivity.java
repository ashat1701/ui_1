package com.example.user.ui_1;

import android.graphics.Bitmap;
import android.graphics.Picture;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PictureDrawable;
import android.media.Image;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.github.ksoichiro.android.observablescrollview.ObservableListView;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollViewCallbacks;
import com.github.ksoichiro.android.observablescrollview.ScrollState;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Observable;

public class MainActivity extends AppCompatActivity implements ObservableScrollViewCallbacks {
    @Override
    public void onScrollChanged(int scrollY, boolean firstScroll, boolean dragging) {

    }

    @Override
    public void onDownMotionEvent() {
    }

    @Override
    public void onUpOrCancelMotionEvent(ScrollState sc) {
        ActionBar ab = getSupportActionBar();
        if (sc == ScrollState.UP && ab.isShowing()) {
            ab.hide();
        } else {
            if (sc == ScrollState.DOWN && !ab.isShowing())
                ab.show();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        ObservableListView listView = (findViewById(R.id.list));
        listView.setScrollViewCallbacks(this);

        ArrayList<ImageView> aa = new ArrayList<>();
        aa.add(new ImageView(this));
        aa.add(new ImageView(this));
        aa.add(new ImageView(this));
        aa.add(new ImageView(this));
        aa.get(0).setImageResource(R.drawable.p1);
        aa.get(1).setImageResource(R.drawable.p2);
        aa.get(2).setImageResource(R.drawable.p3);
        aa.get(3).setImageResource(R.drawable.p4);
        ArrayList<myMem> arrayMemes = new ArrayList<myMem>();
        arrayMemes.add(new myMem("kolansburg", 1, aa.get(0)));
        arrayMemes.add(new myMem("kolansburg", 2, aa.get(1)));
        arrayMemes.add(new myMem("kolansburg", 3, aa.get(2)));
        arrayMemes.add(new myMem("kolansburg", 4, aa.get(3)));
        MemesAdapter adapter = new MemesAdapter(this, arrayMemes);

        listView.setAdapter(adapter);
        ActionB
    }
}