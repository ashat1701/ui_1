package com.example.user.ui_1;

import android.widget.ImageView;

/**
 * Created by User on 07.01.2018.
 */

public class myMem {
    public String name;
    int ordNumber;
    ImageView picture;
    public myMem(String name, int ord, ImageView picture){
        this.name = name;
        this.ordNumber = ord;
        this.picture = picture;
    }
}
